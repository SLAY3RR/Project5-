import React from 'react';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';


class Home extends React.Component {
  render() {
    return (
      <p>Use Material UI component Container and Typography to display a Welcome message here.</p>
    );
  }
}

export default Home;
